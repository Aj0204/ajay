package wiprotraining;
public class BoyerMoore {

    public static int search(String text, String pattern) {
        int n = text.length();
        int m = pattern.length();
        if (m == 0) return -1;
        int[] badCharTable = buildBadCharTable(pattern);
        int[] goodSuffixTable = buildGoodSuffixTable(pattern);

        int lastOccurrence = -1;
        int i = 0;
        while (i <= n - m) {
            int j = m - 1;
            while (j >= 0 && text.charAt(i + j) == pattern.charAt(j)) {
                j--;
            }
            if (j == -1) { 
                lastOccurrence = i;
                i += (i + m < n) ? m - badCharTable[text.charAt(i + m)] : 1;
            } else {
                i += Math.max(badCharTable[text.charAt(i + j)] - m + 1 + j, goodSuffixTable[j]);
            }
        }
        return lastOccurrence; 
    }
    private static int[] buildBadCharTable(String pattern) {
        int[] badCharTable = new int[256];
        for (int i = 0; i < badCharTable.length; i++) {
            badCharTable[i] = -1;
        }
        for (int i = 0; i < pattern.length(); i++) {
            badCharTable[pattern.charAt(i)] = i;
        }
        return badCharTable;
    }
    private static int[] buildGoodSuffixTable(String pattern) {
        int m = pattern.length();
        int[] goodSuffixTable = new int[m];
        int[] suffixes = new int[m];
        suffixes[m - 1] = m;
        int g = m - 1;
        int f = m - 1;
        for (int i = m - 2; i >= 0; --i) {
            if (i > g && suffixes[i + m - 1 - f] < i - g) {
                suffixes[i] = suffixes[i + m - 1 - f];
            } else {
                if (i < g) {
                    g = i;
                }
                f = i;
                while (g >= 0 && pattern.charAt(g) == pattern.charAt(g + m - 1 - f)) {
                    --g;
                }
                suffixes[i] = f - g;
            }
        }
        for (int i = 0; i < m; ++i) {
            goodSuffixTable[i] = m;
        }
        for (int i = m - 1, j = 0; i >= 0; --i) {
            if (suffixes[i] == i + 1) {
                for (; j < m - 1 - i; ++j) {
                    if (goodSuffixTable[j] == m) {
                        goodSuffixTable[j] = m - 1 - i;
                    }
                }
            }
        }
        for (int i = 0; i <= m - 2; ++i) {
            goodSuffixTable[m - 1 - suffixes[i]] = m - 1 - i;
        }
        return goodSuffixTable;
    }

    public static void main(String[] args) {
        String text = "ABAAABCDABCABCABC";
        String pattern = "ABC";
        int index = search(text, pattern);
        if (index != -1) {
            System.out.println("Last occurrence of the pattern found at index " + index);
        } else {
            System.out.println("Pattern not found in the given text");
        }
    }
}

