package wiprotraining;
import java.util.ArrayList;

public class MinHeap {
    private ArrayList<Integer> heap;

    public MinHeap() {
        this.heap = new ArrayList<>();
    }
    private int parent(int index) {
        return (index - 1) / 2;
    }
    private int leftChild(int index) {
        return 2 * index + 1;
    }
    private int rightChild(int index) {
        return 2 * index + 2;
    }
    public void insert(int element) {
        heap.add(element);
        heapifyUp(heap.size() - 1);
    }
    private void heapifyUp(int index) {
        int currentIndex = index;
        while (currentIndex > 0 && heap.get(currentIndex) < heap.get(parent(currentIndex))) {
            swap(currentIndex, parent(currentIndex));
            currentIndex = parent(currentIndex);
        }
    }
    public int getMin() {
        if (heap.isEmpty()) {
            throw new IllegalStateException("Heap is empty");
        }
        return heap.get(0);
    }
    public int deleteMin() {
        if (heap.isEmpty()) {
            throw new IllegalStateException("Heap is empty");
        }
        int min = heap.get(0);
        int lastElement = heap.remove(heap.size() - 1);
        if (!heap.isEmpty()) {
            heap.set(0, lastElement);
            heapifyDown(0);
        }
        return min;
    }
    private void heapifyDown(int index) {
        int currentIndex = index;
        int size = heap.size();

        while (true) {
            int left = leftChild(currentIndex);
            int right = rightChild(currentIndex);
            int smallest = currentIndex;

            if (left < size && heap.get(left) < heap.get(smallest)) {
                smallest = left;
            }
            if (right < size && heap.get(right) < heap.get(smallest)) {
                smallest = right;
            }
            if (smallest == currentIndex) {
                break;
            }
            swap(currentIndex, smallest);
            currentIndex = smallest;
        }
    }
    private void swap(int i, int j) {
        int temp = heap.get(i);
        heap.set(i, heap.get(j));
        heap.set(j, temp);
    }

    public static void main(String[] args) {
        MinHeap minHeap = new MinHeap();
        minHeap.insert(3);
        minHeap.insert(1);
        minHeap.insert(6);
        minHeap.insert(5);
        minHeap.insert(2);
        minHeap.insert(4);

        System.out.println("Minimum element: " + minHeap.getMin()); 
        System.out.println("Deleted minimum element: " + minHeap.deleteMin()); 
        System.out.println("New minimum element: " + minHeap.getMin()); 
    }
}
