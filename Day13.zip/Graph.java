package wiprotraining;
import java.util.ArrayList;
import java.util.List;

class Graph {
    private int numVertices;
    private List<List<Integer>> adjList;

    public Graph(int numVertices) {
        this.numVertices = numVertices;
        adjList = new ArrayList<>(numVertices);
        for (int i = 0; i < numVertices; i++) {
            adjList.add(new ArrayList<>());
        }
    }
    public boolean addEdge(int from, int to) {
        adjList.get(from).add(to);
        if (hasCycle()) {
            adjList.get(from).remove((Integer) to);
            return false;
        }
        return true;
    }
    private boolean hasCycle() {
        boolean[] visited = new boolean[numVertices];
        boolean[] recStack = new boolean[numVertices];

        for (int node = 0; node < numVertices; node++) {
            if (dfs(node, visited, recStack)) {
                return true;
            }
        }
        return false;
    }
    private boolean dfs(int node, boolean[] visited, boolean[] recStack) {
        if (recStack[node]) {
            return true;
        }
        if (visited[node]) {
            return false;
        }

        visited[node] = true;
        recStack[node] = true;

        for (int neighbor : adjList.get(node)) {
            if (dfs(neighbor, visited, recStack)) {
                return true;
            }
        }

        recStack[node] = false;
        return false;
    }

    public static void main(String[] args) {
        Graph graph = new Graph(4);
        System.out.println(graph.addEdge(0, 1)); 
        System.out.println(graph.addEdge(1, 2)); 
        System.out.println(graph.addEdge(2, 3));
        System.out.println(graph.addEdge(3, 1)); 
        System.out.println(graph.addEdge(2, 0)); 
    }
}

