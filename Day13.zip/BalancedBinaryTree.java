package wiprotraining;
class TreeNode {
    int value;
    TreeNode left;
    TreeNode right;

    TreeNode(int value) {
        this.value = value;
        this.left = null;
        this.right = null;
    }
}

public class BalancedBinaryTree {

    public static boolean isBalanced(TreeNode root) {
        return checkBalanceAndHeight(root).balanced;
    }

    private static BalanceStatusWithHeight checkBalanceAndHeight(TreeNode node) {
        if (node == null) {
            return new BalanceStatusWithHeight(true, -1);
        }
        BalanceStatusWithHeight leftResult = checkBalanceAndHeight(node.left);
        if (!leftResult.balanced) {
            return new BalanceStatusWithHeight(false, 0);
        }
        BalanceStatusWithHeight rightResult = checkBalanceAndHeight(node.right);
        if (!rightResult.balanced) {
            return new BalanceStatusWithHeight(false, 0);
        }
        boolean balanced = Math.abs(leftResult.height - rightResult.height) <= 1;

        int height = Math.max(leftResult.height, rightResult.height) + 1;

        return new BalanceStatusWithHeight(balanced, height);
    }

    private static class BalanceStatusWithHeight {
        boolean balanced;
        int height;

        BalanceStatusWithHeight(boolean balanced, int height) {
            this.balanced = balanced;
            this.height = height;
        }
    }

    public static void main(String[] args) {
       
        TreeNode root = new TreeNode(1);
        root.left = new TreeNode(2);
        root.right = new TreeNode(3);
        root.left.left = new TreeNode(4);
        root.left.right = new TreeNode(5);

        System.out.println(isBalanced(root));
    }
}

