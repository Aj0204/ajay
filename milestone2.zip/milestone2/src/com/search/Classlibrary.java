package com.search;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

class Library {
    private List<Book> books;

    public Library() {
        this.books = new ArrayList<>();
    }

    // Add a book to the library
    public void addBook(Book book) {
        books.add(book);
        // Sort books by title for Binary Search
        Collections.sort(books);
    }

    // Remove a book from the library
    public void removeBook(String title) {
        Book found = null;
        for (Book book : books) {
            if (book.getTitle().equals(title)) {
                found = book;
                break;
            }
        }
        if (found != null) {
            books.remove(found);
            System.out.println("Book removed: " + found);
        } else {
            System.out.println("Book not found.");
        }
    }

    // Linear search to find a book by title
    public Book linearSearchByTitle(String title) {
        for (Book book : books) {
            if (book.getTitle().equalsIgnoreCase(title)) {
                return book;
            }
        }
        return null; // Book not found
    }

    // Binary search to find a book by title
    public Book binarySearchByTitle(String title) {
        int low = 0;
        int high = books.size() - 1;

        while (low <= high) {
            int mid = (low + high) / 2;
            Book midBook = books.get(mid);
            int comparison = midBook.getTitle().compareToIgnoreCase(title);

            if (comparison == 0) {
                return midBook; // Found the book
            } else if (comparison < 0) {
                low = mid + 1; // Search the right half
            } else {
                high = mid - 1; // Search the left half
            }
        }

        return null; // Book not found
    }

    // Display all books in the library
    public void displayBooks() {
        System.out.println("Books in the library:");
        for (Book book : books) {
            System.out.println(book);
        }
    }
}

