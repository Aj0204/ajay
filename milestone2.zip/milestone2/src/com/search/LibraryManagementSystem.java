package com.search;
public class LibraryManagementSystem {
    public static void main(String[] args) {
        Library library = new Library();

        // Adding books to the library
        library.addBook(new Book("Effective Java", "Joshua Bloch", "978-0134685991"));
        library.addBook(new Book("Clean Code", "Robert C. Martin", "978-0132350884"));
        library.addBook(new Book("Design Patterns", "Erich Gamma", "978-0201633610"));

        // Display all books
        library.displayBooks();

        // Remove a book
        library.removeBook("Clean Code");
        library.displayBooks();

        // Search for a book using Linear Search
        System.out.println("\nSearching for 'Effective Java' using Linear Search:");
        Book foundLinear = library.linearSearchByTitle("Effective Java");
        if (foundLinear != null) {
            System.out.println("Book found: " + foundLinear);
        } else {
            System.out.println("Book not found.");
        }

        // Search for a book using Binary Search
        System.out.println("\nSearching for 'Design Patterns' using Binary Search:");
        Book foundBinary = library.binarySearchByTitle("Design Patterns");
        if (foundBinary != null) {
            System.out.println("Book found: " + foundBinary);
        } else {
            System.out.println("Book not found.");
        }
    }
}

