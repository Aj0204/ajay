package com.liststackqueue;
import java.util.Stack;
import java.util.LinkedList;

public class PurchaseHistory {
    private Stack<LinkedList<String>> history;

    public PurchaseHistory() {
        this.history = new Stack<>();
    }

    // Method to save current cart to purchase history
    public void addToHistory(LinkedList<String> cart) {
        LinkedList<String> cartCopy = new LinkedList<>(cart); // Copy the current cart
        history.push(cartCopy);
        System.out.println("Cart added to purchase history.");
    }

    // Method to undo last purchase and retrieve the last cart
    public LinkedList<String> undoLastPurchase() {
        if (!history.isEmpty()) {
            return history.pop();
        } else {
            System.out.println("No purchase history available.");
            return new LinkedList<>();
        }
    }

    // Method to view entire purchase history
    public void viewPurchaseHistory() {
        if (history.isEmpty()) {
            System.out.println("Purchase history is empty.");
        } else {
            System.out.println("Purchase History:");
            for (LinkedList<String> cart : history) {
                System.out.println(cart);
            }
        }
    }
}

