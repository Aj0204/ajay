package com.liststackqueue;
import java.util.Queue;
import java.util.LinkedList;

public class CustomerService {
    private Queue<String> serviceRequests;

    public CustomerService() {
        this.serviceRequests = new LinkedList<>();
    }

    // Method to add a customer service request
    public void addRequest(String request) {
        serviceRequests.offer(request);
        System.out.println("Service request added: " + request);
    }

    // Method to process the next customer service request
    public String processNextRequest() {
        String request = serviceRequests.poll();
        if (request != null) {
            System.out.println("Processing request: " + request);
        } else {
            System.out.println("No pending service requests.");
        }
        return request;
    }

    // Method to view pending customer service requests
    public void viewPendingRequests() {
        if (serviceRequests.isEmpty()) {
            System.out.println("No pending service requests.");
        } else {
            System.out.println("Pending Service Requests:");
            for (String request : serviceRequests) {
                System.out.println(request);
            }
        }
    }

    // Getter to check if there are pending requests
    public boolean hasPendingRequests() {
        return !serviceRequests.isEmpty();
    }
}

