package com.liststackqueue;
import java.util.LinkedList;

public class ShoppingApp {
    public static void main(String[] args) {
        ShoppingCart cart = new ShoppingCart();
        PurchaseHistory history = new PurchaseHistory();
        CustomerService service = new CustomerService();

        // Adding items to the cart
        cart.addItem("Laptop");
        cart.addItem("Headphones");
        cart.addItem("Mouse");

        // Displaying all items in the cart
        cart.viewCart();

        // Adding the current cart to purchase history
        LinkedList<String> currentCart = cart.getCartItems();
        history.addToHistory(currentCart);

        // Undoing the last purchase
        System.out.println("\nUndoing the last purchase:");
        history.undoLastPurchase();
        history.viewPurchaseHistory();

        // Adding customer service requests
        service.addRequest("Return request");
        service.addRequest("Refund inquiry");

        // Displaying pending customer service requests
        service.viewPendingRequests();

        // Processing next customer service request
        service.processNextRequest();
        service.processNextRequest();
        service.processNextRequest(); // No pending requests
    }
}
