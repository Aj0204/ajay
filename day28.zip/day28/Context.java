package day28;
	import java.util.List;

	public class Context {
	    private SortingStrategy sortingStrategy;

	    public Context(SortingStrategy sortingStrategy) {
	        this.sortingStrategy = sortingStrategy;
	    }

	    public void setSortingStrategy(SortingStrategy sortingStrategy) {
	        this.sortingStrategy = sortingStrategy;
	    }

	    public void sort(List<Integer> numbers) {
	        sortingStrategy.sort(numbers);
	    }

	    public static void main(String[] args) {
	        List<Integer> numbers = List.of(5, 3, 8, 1, 2);

	        // Create context with BubbleSort strategy
	        Context context = new Context(new BubbleSort());
	        context.sort(numbers);

	        // Change strategy to QuickSort
	        context.setSortingStrategy(new QuickSort());
	        context.sort(numbers);

	        // Change strategy to MergeSort
	        context.setSortingStrategy(new MergeSort());
	        context.sort(numbers);
	    }
	}

	interface SortingStrategy {
	    void sort(List<Integer> numbers);
	}

	class BubbleSort implements SortingStrategy {
	    @Override
	    public void sort(List<Integer> numbers) {
	        System.out.println("Sorting using Bubble Sort");
	        // Implement Bubble Sort algorithm here
	    }
	}

	class QuickSort implements SortingStrategy {
	    @Override
	    public void sort(List<Integer> numbers) {
	        System.out.println("Sorting using Quick Sort");
	        // Implement Quick Sort algorithm here
	    }
	}

	class MergeSort implements SortingStrategy {
	    @Override
	    public void sort(List<Integer> numbers) {
	        System.out.println("Sorting using Merge Sort");
	        // Implement Merge Sort algorithm here
	    }
	}
