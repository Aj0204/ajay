package day28;
//Define the Shape interface
interface Shape {
 void draw();
}

//Implement the Circle class
class Circle implements Shape {
 @Override
 public void draw() {
     System.out.println("Drawing a Circle");
 }
}

//Implement the Square class
class Square implements Shape {
 @Override
 public void draw() {
     System.out.println("Drawing a Square");
 }
}

//Implement the Rectangle class
class Rectangle implements Shape {
 @Override
 public void draw() {
     System.out.println("Drawing a Rectangle");
 }
}

//Implement the ShapeFactory class
class ShapeFactory {

 // Factory method to create shapes
 public Shape getShape(String shapeType) {
     if (shapeType == null) {
         return null;
     }
     if (shapeType.equalsIgnoreCase("CIRCLE")) {
         return new Circle();
     } else if (shapeType.equalsIgnoreCase("SQUARE")) {
         return new Square();
     } else if (shapeType.equalsIgnoreCase("RECTANGLE")) {
         return new Rectangle();
     }
     return null;
 }
}

//Main class to test the ShapeFactory
public class FactoryMethodPatternDemo {
 public static void main(String[] args) {
     ShapeFactory shapeFactory = new ShapeFactory();

     // Get an object of Circle and call its draw method
     Shape shape1 = shapeFactory.getShape("CIRCLE");
     shape1.draw(); // Output: Drawing a Circle

     // Get an object of Square and call its draw method
     Shape shape2 = shapeFactory.getShape("SQUARE");
     shape2.draw(); // Output: Drawing a Square

     // Get an object of Rectangle and call its draw method
     Shape shape3 = shapeFactory.getShape("RECTANGLE");
     shape3.draw(); // Output: Drawing a Rectangle
 }
}

