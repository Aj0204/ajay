package day28;
public class ProxyDemo {
    public static class SensitiveObject {
        private String secretKey;

        public SensitiveObject(String secretKey) {
            this.secretKey = secretKey;
        }

        public String getSecretKey() {
            return secretKey;
        }
    }

    public static class Proxy {
        private SensitiveObject sensitiveObject;
        private String password;

        public Proxy(SensitiveObject sensitiveObject, String password) {
            this.sensitiveObject = sensitiveObject;
            this.password = password;
        }

        public String accessSecretKey(String password) throws IllegalAccessException {
            if (this.password.equals(password)) {
                return sensitiveObject.getSecretKey();
            } else {
                throw new IllegalAccessException("Access denied: Incorrect password");
            }
        }
    }

    public static void main(String[] args) {
        String secretKey = "my_secret_key_123";
        String correctPassword = "password123";

        SensitiveObject sensitiveObject = new SensitiveObject(secretKey);
        Proxy proxy = new Proxy(sensitiveObject, correctPassword);

        try {
            // Attempt to access the secret key with the correct password
            System.out.println("Accessing with correct password...");
            String secret = proxy.accessSecretKey("password123");
            System.out.println("Secret Key: " + secret);

            // Attempt to access the secret key with an incorrect password
            System.out.println("Accessing with incorrect password...");
            secret = proxy.accessSecretKey("wrongpassword");
            System.out.println("Secret Key: " + secret);
        } catch (IllegalAccessException e) {
            System.out.println(e.getMessage());
        }
    }
}

