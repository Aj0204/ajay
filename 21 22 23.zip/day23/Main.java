package day23;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Main {
    public static void main(String[] args) throws InterruptedException {
        Counter counter = new Counter();
        ImmutableData immutableData = new ImmutableData(10);

        Thread incrementThread = new Thread(() -> {
            for (int i = 0; i < 1000; i++) {
                counter.increment();
            }
        });

        Thread decrementThread = new Thread(() -> {
            for (int i = 0; i < 1000; i++) {
                counter.decrement();
            }
        });

        Thread readThread = new Thread(() -> {
            System.out.println("Immutable Data Value: " + immutableData.getValue());
        });

        incrementThread.start();
        decrementThread.start();
        readThread.start();

        incrementThread.join();
        decrementThread.join();
        readThread.join();

        System.out.println("Counter Value: " + counter.getCount());
    }
}

class Counter {
    private int count;
    private final Lock lock = new ReentrantLock();

    public Counter() {
        this.count = 0;
    }

    public void increment() {
        lock.lock();
        try {
            count++;
        } finally {
            lock.unlock();
        }
    }

    public void decrement() {
        lock.lock();
        try {
            count--;
        } finally {
            lock.unlock();
        }
    }

    public int getCount() {
        return count;
    }
}

final class ImmutableData {
    private final int value;

    public ImmutableData(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }
}

