package day23;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ThreadPoolExample {

    public static void main(String[] args) {
        ExecutorService executor = Executors.newFixedThreadPool(5);
        for (int i = 0; i < 10; i++) {
            int taskNumber = i;
            executor.submit(() -> {
            
                System.out.println("Task " + taskNumber + " started by thread " + Thread.currentThread().getName());
                try {
                    Thread.sleep(2000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                System.out.println("Task " + taskNumber + " completed by thread " + Thread.currentThread().getName());
            });
        }

        executor.shutdown();
    }
}
