package day23;

public class ProducerConsumer {
	    private final int MAX_BUFFER_SIZE = 10;
	    private int buffer[] = new int[MAX_BUFFER_SIZE];
	    private int in = 0, out = 0, count = 0;

	    public synchronized void produce(int item) throws InterruptedException {
	        while (count == MAX_BUFFER_SIZE) {
	            wait();
	        }
	        buffer[in] = item;
	        in = (in + 1) % MAX_BUFFER_SIZE;
	        count++;
	        notifyAll();
	        System.out.println("Produced: " + item);
	    }

	    public synchronized int consume() throws InterruptedException {
	        while (count == 0) {
	            wait();
	        }
	        int item = buffer[out];
	        out = (out + 1) % MAX_BUFFER_SIZE;
	        count--;
	        notifyAll();
	        System.out.println("Consumed: " + item);
	        return item;
	    }

	    public static void main(String[] args) throws InterruptedException {
	        ProducerConsumer pc = new ProducerConsumer();

	        Thread producerThread = new Thread(() -> {
	            for (int i = 1; i <= 20; i++) {
	                try {
	                    pc.produce(i);
	                    Thread.sleep(100);
	                } catch (InterruptedException e) {
	                    e.printStackTrace();
	                }
	            }
	        });

	        Thread consumerThread1 = new Thread(() -> {
	            for (int i = 1; i <= 10; i++) {
	                try {
	                    pc.consume();
	                    Thread.sleep(500);
	                } catch (InterruptedException e) {
	                    e.printStackTrace();
	                }
	            }
	        });

	        Thread consumerThread2 = new Thread(() -> {
	            for (int i = 11; i <= 20; i++) {
	                try {
	                    pc.consume();
	                    Thread.sleep(200);
	                } catch (InterruptedException e) {
	                    e.printStackTrace();
	                }
	            }
	        });

	        producerThread.start();
	        consumerThread1.start();
	        consumerThread2.start();

	        producerThread.join();
	        consumerThread1.join();
	        consumerThread2.join();
	    }
	}
