package day23;
public class GenericClassesandMethods {
    public static void main(String[] args) {
        Integer[] intArray = {1, 2, 3, 4, 5};
        System.out.println("Original Integer array:");
        printArray(intArray);
        swap(intArray, 0, 4);
        System.out.println("After swapping:");
        printArray(intArray);
        
        String[] stringArray = {"apple", "banana", "orange", "pear"};
        System.out.println("\nOriginal String array:");
        printArray(stringArray);
        swap(stringArray, 1, 3);
        System.out.println("After swapping:");
        printArray(stringArray);
        
        Character[] charArray = {'a', 'b', 'c', 'd', 'e'};
        System.out.println("\nOriginal Character array:");
        printArray(charArray);
        swap(charArray, 2, 4);
        System.out.println("After swapping:");
        printArray(charArray);
    }

    public static <T> void swap(T[] array, int index1, int index2) {
        if (index1 < 0 || index1 >= array.length || index2 < 0 || index2 >= array.length) {
            throw new IllegalArgumentException("Invalid indices");
        }
        T temp = array[index1];
        array[index1] = array[index2];
        array[index2] = temp;
    }

    public static <T> void printArray(T[] array) {
        for (T element : array) {
            System.out.print(element + " ");
        }
        System.out.println();
    }
}
