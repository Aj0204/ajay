package day23;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class PrimeNumberCalculator {

    public static void main(String[] args) {
        int upperBound = 100;

        // Create an ExecutorService with fixed number of threads
        ExecutorService executor = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());

        // Calculate prime numbers in parallel
        CompletableFuture<List<Integer>> future = CompletableFuture.supplyAsync(() -> calculatePrimes(upperBound), executor);

        // Print the prime numbers to the console
        future.thenAcceptAsync(primeNumbers -> {
            System.out.println("Prime numbers:");
            for (Integer prime : primeNumbers) {
                System.out.println(prime);
            }
        }, executor);

        // Shutdown the executor
        executor.shutdown();
    }

    private static List<Integer> calculatePrimes(int upperBound) {
        List<Integer> primes = new ArrayList<>();
        for (int i = 2; i <= upperBound; i++) {
            if (isPrime(i)) {
                primes.add(i);
            }
        }
        return primes;
    }

    private static boolean isPrime(int number) {
        if (number <= 1) {
            return false;
        }
        for (int i = 2; i <= Math.sqrt(number); i++) {
            if (number % i == 0) {
                return false;
            }
        }
        return true;
    }
}

