package wiprotraining;

public class reversearray {
	public static void main(String[] args) {
		int[] number = new int[5];
		for(int i = 0; i< number.length; i++) {
			number[i] = i + 1; 
		}
		System.out.println("Original array");
		for(int num : number) {
			System.out.println(num+"");
		}
		System.out.println("\nArray in reverse order:");
		for(int i = number.length -1; i>-0; i--) {
			System.out.println(number[i]+"");
		}
	}

}
