package wiprotraining;
import java.util.Arrays;
import java.util.Random;

public class Bruteforce {
    
    public static void bruteForceSort(int[] arr) {
        int n = arr.length;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (arr[j] > arr[j+1]) {
                    int temp = arr[j];
                    arr[j] = arr[j+1];
                    arr[j+1] = temp;
                }
            }
        }
    }
    
    public static int[] initializeArray(int size, int start, int end) {
        int[] arr = new int[size];
        Random rand = new Random();
        for (int i = 0; i < size; i++) {
            arr[i] = rand.nextInt(end - start + 1) + start;
        }
        return arr;
    }

    public static void main(String[] args) {
        int size = 10;
        int start = 0;
        int end = 100;
        int[] arr = initializeArray(size, start, end);
        System.out.println("Original Array: " + Arrays.toString(arr));
        bruteForceSort(arr);
        System.out.println("Sorted Array: " + Arrays.toString(arr));
    }
}



