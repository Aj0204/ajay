package wiprotraining;
import java.util.ArrayList;
import java.util.EmptyStackException;

public class Customqueue<T> {
    private ArrayList<T> queue;

    public Customqueue() {
        queue = new ArrayList<>();
    }

    public void enqueue(T item) {
        queue.add(item);
    }

    public T dequeue() {
        if (isEmpty()) {
            throw new EmptyStackException();
        }
        return queue.remove(0);
    }

    public T peek() {
        if (isEmpty()) {
            throw new EmptyStackException();
        }
        return queue.get(0);
    }

    public boolean isEmpty() {
        return queue.isEmpty();
    }

    public static void main(String[] args) {
        Customqueue<String> stringQueue = new Customqueue<>();
        stringQueue.enqueue("Apple");
        stringQueue.enqueue("Banana");
        stringQueue.enqueue("Orange");
        System.out.println("Dequeuing strings:");
        while (!stringQueue.isEmpty()) {
            System.out.println(stringQueue.dequeue());
        }
        Customqueue<Integer> integerQueue = new Customqueue<>();
        integerQueue.enqueue(1);
        integerQueue.enqueue(2);
        integerQueue.enqueue(3);
        System.out.println("Dequeuing integers:");
        while (!integerQueue.isEmpty()) {
            System.out.println(integerQueue.dequeue());
        }
    }
}

