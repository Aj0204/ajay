package wiprotraining;
public class Fibonacci {
    public static int fibonacci(int n) {
        if (n <= 1) {
            return n;
        } else {
            return fibonacci(n - 1) + fibonacci(n - 2);
        }
    }

    public static int[] fibonacciSequence(int n) {
        int[] sequence = new int[n];
        for (int i = 0; i < n; i++) {
            sequence[i] = fibonacci(i);
        }
        return sequence;
    }

    public static void main(String[] args) {
        int n = 10;
        int[] sequence = fibonacciSequence(n);
        System.out.println("Fibonacci sequence of length " + n + ":");
        for (int i = 0; i < n; i++) {
            System.out.print(sequence[i] + " ");
        }
        int nthElement = fibonacci(n - 1);
        System.out.println("\nThe " + n + "th element of the Fibonacci sequence is: " + nthElement);
    }
}

