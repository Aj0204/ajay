package wiprotraining;
public class Recursivesum{
    public static void main(String[] args){
        int[] Array = {1, 2, 3, 4, 5, 6, 7, 8, 9};
        System.out.println("Array  = " + recursivesum(Array, 0));
    }
    public static int recursivesum(int[] numbers, int index){
        if(index == numbers.length - 1 ){
            return numbers[index];
        }
        return numbers[index] + recursivesum(numbers, index + 1);
    }
}
