package wiprotraining;
public class Stringmanipulation {
    public static String extractMiddleSubstring(String str1, String str2, int length) {
        String concatenated = str1.concat(str2);
        String reversed = new StringBuilder(concatenated).reverse().toString();
        if (reversed.isEmpty() || length > reversed.length()) {
            return "Invalid input";
        }
        int startIndex = (reversed.length() - length) / 2;
        String middleSubstring = reversed.substring(startIndex, startIndex + length);

        return middleSubstring;
    }

    public static void main(String[] args) {
        String str1 = "Hello";
        String str2 = "World";
        int length = 5;

        String result = extractMiddleSubstring(str1, str2, length);
        System.out.println("Middle substring of length " + length + ": " + result);
    }
}
