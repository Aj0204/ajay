package wiprotraining;
import java.util.HashSet;
public class Twosum { 
    public boolean hasTwoSum(int[] nums, int target) {
        HashSet<Integer> set = new HashSet<>();
        for (int num : nums) {
            int complement = target - num;
            if (set.contains(complement)) {
                return true;
            }
            set.add(num);
        }
        return false;
    }
     public static void main(String[] args) {
        Twosum twoSum = new Twosum();
        int[] nums = {2, 7, 11, 15};
        int target = 9;
        System.out.println("Result: " + twoSum.hasTwoSum(nums, target));
    }
}


