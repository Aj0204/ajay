package wiprotraining;
import java.util.List;
import java.util.ArrayList;

public class Listinterface {
    public static void removeEverySecondElement(List<Integer> list) {
        for (int i = 1; i < list.size(); i += 2) {
            list.remove(i);
        }
        System.out.println("Resulting list after removing every second element: " + list);
    }

    public static void main(String[] args) {
        List<Integer> myList = new ArrayList<>();
        myList.add(1);
        myList.add(2);
        myList.add(3);
        myList.add(4);
        myList.add(5);

        System.out.println("Original list: " + myList);

        removeEverySecondElement(myList);
    }
}

