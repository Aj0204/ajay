package wiprotraining;
import java.util.Stack;

public class StackSequenceSearch {

    public static boolean isSequencePresent(Stack<Integer> stack, int[] sequence) {
        int index = 0;
        while (!stack.isEmpty()) {
            int element = stack.pop();

            if (element == sequence[index]) {
                index++; 
            }
            if (index == sequence.length) {
                return true;
            }
        }
        return false;
    }

    public static void main(String[] args) {
        Stack<Integer> stack = new Stack<>();
        stack.push(1);
        stack.push(2);
        stack.push(3);
        stack.push(4);
        stack.push(5);

        int[] sequence1 = {1, 2, 3}; 
        int[] sequence2 = {4, 5, 6}; 

        System.out.println("Sequence 1 present: " + isSequencePresent(stack, sequence1)); // true
        System.out.println("Sequence 2 present: " + isSequencePresent(stack, sequence2)); // false
    }
}

