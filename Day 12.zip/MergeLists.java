package wiprotraining;
public class MergeLists {

    public static class ListNode {
        int val;
        ListNode next;

        ListNode(int x) {
            val = x;
        }
    }

    public static ListNode mergeTwoLists(ListNode list1, ListNode list2) {
        if (list1 == null) return list2;
        if (list2 == null) return list1;

        ListNode mergedHead = list1.val < list2.val ? list1 : list2;

        ListNode tail = mergedHead;
        while (list1 != null && list2 != null) {
            if (list1.val < list2.val) {
                tail = list1;
                list1 = list1.next;
            } else {
                tail = list2;
                list2 = list2.next;
            }
            tail.next = (list1 != null) ? list1 : list2;
        }
        tail.next = (list1 != null) ? list1 : list2;

        return mergedHead;
    }

    public static void main(String[] args) {
        ListNode list1 = new ListNode(1);
        list1.next = new ListNode(2);
        list1.next.next = new ListNode(4);
        list1.next.next.next = new ListNode(6);
        list1.next.next.next.next = new ListNode(8);

        ListNode list2 = new ListNode(1);
        list2.next = new ListNode(3);
        list2.next.next = new ListNode(4);
        list2.next.next.next = new ListNode(5);
        list2.next.next.next.next = new ListNode(7);

        ListNode mergedList = mergeTwoLists(list1, list2);
        while (mergedList != null) {
            System.out.print(mergedList.val + " -> ");
            mergedList = mergedList.next;
        }
        System.out.println("NULL");
    }
}

