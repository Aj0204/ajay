package day24;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

	public class PersonSorter {
	    public static void main(String[] args) {
	        // Define the Person class
	        class Person {
	            private String name;
	            private int age;

	            public Person(String name, int age) {
	                this.name = name;
	                this.age = age;
	            }

	            public int getAge() {
	                return age;
	            }

	            @Override
	            public String toString() {
	                return "Person{name='" + name + "', age=" + age + "}";
	            }
	        }

	        // Create a list of Person objects
	        List<Person> people = new ArrayList<>();
	        people.add(new Person("Arun", 30));
	        people.add(new Person("Babu", 25));
	        people.add(new Person("Chandu", 35));
	        people.add(new Person("Danush", 20));

	        // Sort the list by age using a lambda expression
	        people.sort(Comparator.comparingInt(Person::getAge));

	        // Print the sorted list
	        for (Person person : people) {
	            System.out.println(person);
	        }
	    }
	}