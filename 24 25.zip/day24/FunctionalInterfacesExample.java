package day24;
	import java.util.function.Predicate;
	import java.util.function.Function;
	import java.util.function.Consumer;
	import java.util.function.Supplier;

	public class FunctionalInterfacesExample {

	    public static void main(String[] args) {
	   
	        Person person = new Person("Alice", 30);

	        Predicate<Person> isAdult = p -> p.getAge() >= 18;
	        System.out.println("Is adult: " + checkPerson(person, isAdult));

	        Function<Person, Integer> nameLength = p -> p.getName().length();
	        System.out.println("Name length: " + getPersonAttribute(person, nameLength));

	        Consumer<Person> printPerson = p -> System.out.println("Person details: " + p);
	        consumePerson(person, printPerson);

	        Supplier<Person> personSupplier = () -> new Person("Bob", 25);
	        Person newPerson = supplyPerson(personSupplier);
	        System.out.println("New person: " + newPerson);
	    }

	    public static boolean checkPerson(Person person, Predicate<Person> predicate) {
	        return predicate.test(person);
	    }

	    public static <R> R getPersonAttribute(Person person, Function<Person, R> function) {
	        return function.apply(person);
	    }

	    public static void consumePerson(Person person, Consumer<Person> consumer) {
	        consumer.accept(person);
	    }

	    public static Person supplyPerson(Supplier<Person> supplier) {
	        return supplier.get();
	    }

	    public static class Person {
	        private String name;
	        private int age;

	        public Person(String name, int age) {
	            this.name = name;
	            this.age = age;
	        }

	        public String getName() {
	            return name;
	        }

	        public void setName(String name) {
	            this.name = name;
	        }

	        public int getAge() {
	            return age;
	        }

	        public void setAge(int age) {
	            this.age = age;
	        }

	        @Override
	        public String toString() {
	            return "Person{name='" + name + "', age=" + age + "}";
	        }
	    }
	}
