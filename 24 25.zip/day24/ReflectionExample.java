package day24;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class ReflectionExample {
    
    public static void main(String[] args) {
        try {
            class Person {
                private String name;
                private int age;

                public Person() {
                    this.name = "Unknown";
                    this.age = 0;
                }

                public Person(String name, int age) {
                    this.name = name;
                    this.age = age;
                }

                private void display() {
                    System.out.println("Name: " + name + ", Age: " + age);
                }

                public String getName() {
                    return name;
                }

                public int getAge() {
                    return age;
                }
            }

            Class<?> personClass = Person.class;
            
            System.out.println("Constructors:");
            for (Constructor<?> constructor : personClass.getDeclaredConstructors()) {
                System.out.println(constructor);
            }

            System.out.println("\nMethods:");
            for (Method method : personClass.getDeclaredMethods()) {
                System.out.println(method);
            }

            System.out.println("\nFields:");
            for (Field field : personClass.getDeclaredFields()) {
                System.out.println(field);
            }

            Constructor<?> constructor = personClass.getDeclaredConstructor(String.class, int.class);
            Object personInstance = constructor.newInstance("kate", 30);

            Field nameField = personClass.getDeclaredField("name");
            nameField.setAccessible(true); 
            System.out.println("\nOriginal Name: " + nameField.get(personInstance));
            
            nameField.set(personInstance, "jack");
            System.out.println("Updated Name: " + nameField.get(personInstance));
            
            Method displayMethod = personClass.getDeclaredMethod("display");
            displayMethod.setAccessible(true);
            displayMethod.invoke(personInstance);
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}


