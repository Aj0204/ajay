package day25;

import java.io.*;
import java.util.*;

public class WordFrequencyCounter {

    public static void main(String[] args) {
        if (args.length < 2) {
            System.out.println("Usage: java WordFrequencyCounter <inputFile> <outputFile>");
            return;
        }

        String inputFile = args[0];
        String outputFile = args[1];

        Map<String, Integer> wordCounts = new TreeMap<>();

        try (FileReader fileReader = new FileReader(inputFile);
             BufferedReader bufferedReader = new BufferedReader(fileReader)) {
        	 String line;
             while ((line = bufferedReader.readLine()) != null) {
                 String[] words = line.split("\\W+");

                 for (String word : words) {
                     if (!word.isEmpty()) {
                         word = word.toLowerCase(); // Convert word to lowercase
                         wordCounts.put(word, wordCounts.getOrDefault(word, 0) + 1);
                     }
                 }
             }

         } catch (IOException e) {
             System.out.println("Error reading the file: " + e.getMessage());
         }
        try (FileWriter fileWriter = new FileWriter(outputFile);
                BufferedWriter bufferedWriter = new BufferedWriter(fileWriter)) {

               for (Map.Entry<String, Integer> entry : wordCounts.entrySet()) {
                   bufferedWriter.write(entry.getKey() + ": " + entry.getValue());
                   bufferedWriter.newLine();
               }

           } catch (IOException e) {
        	   
               System.out.println("Error writing the file: " + e.getMessage());
       }
   }
   }

