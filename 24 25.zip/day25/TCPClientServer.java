package day25;
	import java.io.*;
	import java.net.ServerSocket;
	import java.net.Socket;
	import java.util.concurrent.ExecutorService;
	import java.util.concurrent.Executors;

	public class TCPClientServer {

	    static class OperationRequest implements Serializable {
	        private static final long serialVersionUID = 1L;
	        private int number1;
	        private int number2;
	        private String operation;

	        public OperationRequest(int number1, int number2, String operation) {
	            this.number1 = number1;
	            this.number2 = number2;
	            this.operation = operation;
	        }

	        public int getNumber1() {
	            return number1;
	        }

	        public int getNumber2() {
	            return number2;
	        }

	        public String getOperation() {
	            return operation;
	        }
	    }

	    public static void main(String[] args) {
	        ExecutorService executor = Executors.newFixedThreadPool(2);

	        executor.execute(TCPClientServer::startServer);
	        executor.execute(TCPClientServer::startClient);

	        executor.shutdown();
	    }

	    public static void startServer() {
	        try (ServerSocket serverSocket = new ServerSocket(9876)) {
	            System.out.println("Server is listening on port 9876");

	            while (true) {
	                try (Socket socket = serverSocket.accept();
	                     ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
	                     ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream())) {

	                    OperationRequest request = (OperationRequest) ois.readObject();
	                    int result = performOperation(request.getNumber1(), request.getNumber2(), request.getOperation());

	                    oos.writeObject(result);
	                    oos.flush();
	                } catch (IOException | ClassNotFoundException e) {
	                    e.printStackTrace();
	                }
	            }
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }

	    private static int performOperation(int number1, int number2, String operation) {
	        switch (operation) {
	            case "+":
	                return number1 + number2;
	            case "-":
	                return number1 - number2;
	            case "*":
	                return number1 * number2;
	            case "/":
	                return number2 != 0 ? number1 / number2 : 0; // Simple division, not handling all edge cases
	            default:
	                return 0;
	        }
	    }

	    public static void startClient() {
	        String hostname = "localhost";
	        int port = 9876;

	        try (Socket socket = new Socket(hostname, port);
	             ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
	             ObjectInputStream ois = new ObjectInputStream(socket.getInputStream())) {

	            OperationRequest request = new OperationRequest(2, 2, "+");

	            oos.writeObject(request);
	            oos.flush();

	            int result = (int) ois.readObject();
	            System.out.println("Result from server: " + result);

	        } catch (IOException | ClassNotFoundException e) {
	            e.printStackTrace();
	        }
	    }
	}
