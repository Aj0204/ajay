package day25;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;

	public class NIOExample {
	    public static void main(String[] args) {
	        Path sourcePath = Paths.get("abc.txt");
	        Path destinationPath = Paths.get("destination.txt");

	        if (!Files.exists(sourcePath)) {
	            System.out.println("The source file 'abc.txt' does not exist. Please create the file and add some content.");
	            return;
	        }

	        try (FileChannel sourceChannel = FileChannel.open(sourcePath, StandardOpenOption.READ);
	             FileChannel destinationChannel = FileChannel.open(destinationPath, StandardOpenOption.WRITE, StandardOpenOption.CREATE)) {

	            ByteBuffer buffer = ByteBuffer.allocate(1024);

	            while (sourceChannel.read(buffer) > 0) {
	                buffer.flip(); 
	                destinationChannel.write(buffer);
	                buffer.clear(); 
	            }

	            System.out.println("File copied successfully!");

	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }
	}
