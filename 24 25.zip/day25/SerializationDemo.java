package day25;
import java.io.*;
  public class SerializationDemo {
	    public static void main(String[] args) {
	        String directory = "/tmp/serialization_demo";
	        String filename = directory + "/person.ser";

	        File dir = new File(directory);
	        if (!dir.exists()) {
	            dir.mkdirs(); 
	        }

	        Person person = new Person("krish", 25);

	        serializePerson(person, filename);

	        Person deserializedPerson = deserializePerson(filename);

	        if (deserializedPerson != null) {
	            System.out.println("Deserialized Person:");
	            System.out.println("Name: " + deserializedPerson.getName());
	            System.out.println("Age: " + deserializedPerson.getAge());
	        }
	    }

	    public static void serializePerson(Person person, String filename) {
	        try (FileOutputStream fileOut = new FileOutputStream(filename);
	             ObjectOutputStream out = new ObjectOutputStream(fileOut)) {
	            out.writeObject(person);
	            System.out.println("Serialized data is saved in " + filename);
	        } catch (IOException i) {
	            i.printStackTrace();
	        }
	    }

	    public static Person deserializePerson(String filename) {
	        Person person = null;
	        try (FileInputStream fileIn = new FileInputStream(filename);
	             ObjectInputStream in = new ObjectInputStream(fileIn)) {
	            person = (Person) in.readObject();
	        } catch (IOException i) {
	            i.printStackTrace();
	        } catch (ClassNotFoundException c) {
	            System.out.println("Person class not found");
	            c.printStackTrace();
	        }
	        return person;
	    }
	}

	class Person implements Serializable {
	    private static final long serialVersionUID = 1L;
	    
	    private String name;
	    private int age;
	    
	    public Person(String name, int age) {
	        this.name = name;
	        this.age = age;
	    }

	    public String getName() {
	        return name;
	    }

	    public int getAge() {
	        return age;
	    }
	}
