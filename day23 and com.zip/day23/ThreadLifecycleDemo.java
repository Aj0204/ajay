package day23;

public class ThreadLifecycleDemo {
	    public static void main(String[] args) {
	        ThreadState threadState = new ThreadState();
	        Thread thread = new Thread(threadState);

	        System.out.println("Thread State after creation: " + thread.getState());

	        thread.start();

	        System.out.println("Thread State after calling start(): " + thread.getState());

	        try {
	        
	            Thread.sleep(2000);
	            System.out.println("Thread State after sleep(): " + thread.getState());
	            
	            thread.join();

	            System.out.println("Thread State after join(): " + thread.getState());
	        } catch (InterruptedException e) {
	            e.printStackTrace();
	        }
	    }
	}

	class ThreadState implements Runnable {
	    @Override
	    public void run() {
	        synchronized (this) {
	            try {
	                System.out.println("Thread is going to sleep for 3 seconds.");
	                Thread.sleep(3000);

	                System.out.println("Thread is waiting.");
	                wait();

	                System.out.println("Thread is notified and runnable.");
	            } catch (InterruptedException e) {
	                e.printStackTrace();
	            }
	        }
	    }
	}
