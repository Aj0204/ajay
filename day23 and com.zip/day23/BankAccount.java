package day23;

public class BankAccount {
	    private int balance = 0;

	    public synchronized void deposit(int amount) {
	        balance += amount;
	        System.out.println("Deposited: " + amount + ", New Balance: " + balance);
	    }

	    public synchronized void withdraw(int amount) throws InterruptedException {
	        if (balance < amount) {
	            System.out.println("Insufficient balance. Please wait for deposits.");
	            wait();
	        }
	        balance -= amount;
	        System.out.println("Withdrew: " + amount + ", New Balance: " + balance);
	    }

	    public static void main(String[] args) {
	        BankAccount account = new BankAccount();

	        Thread depositorThread = new Thread(() -> {
	            for (int i = 0; i < 10; i++) {
	                account.deposit(100);
	                try {
	                    Thread.sleep(100);
	                } catch (InterruptedException e) {
	                    e.printStackTrace();
	                }
	            }
	        });

	        Thread withdrawerThread = new Thread(() -> {
	            for (int i = 0; i < 10; i++) {
	                try {
	                    account.withdraw(50);
	                    Thread.sleep(200);
	                } catch (InterruptedException e) {
	                    e.printStackTrace();
	                }
	            }
	        });

	        depositorThread.start();
	        withdrawerThread.start();

	        try {
	            depositorThread.join();
	            withdrawerThread.join();
	        } catch (InterruptedException e) {
	            e.printStackTrace();
	        }
	    }
	}
