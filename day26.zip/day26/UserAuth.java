package day26;

public class UserAuth {

}
