package day26;
	import java.time.LocalDateTime;
	import java.time.ZoneId;
	import java.time.ZonedDateTime;
	import java.time.format.DateTimeFormatter;
	import java.util.Scanner;

	public class TimezoneConverter {
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

	        System.out.println("Enter the date and time (yyyy-MM-dd HH:mm): ");
	        String dateTimeInput = scanner.nextLine();
	        LocalDateTime localDateTime = LocalDateTime.parse(dateTimeInput, formatter);

	        System.out.println("Enter the source timezone (e.g., America/New_York): ");
	        String sourceTimezone = scanner.nextLine();
	        ZoneId sourceZoneId = ZoneId.of(sourceTimezone);

	        ZonedDateTime sourceZonedDateTime = localDateTime.atZone(sourceZoneId);

	        System.out.println("Enter the target timezone (e.g., Europe/London): ");
	        String targetTimezone = scanner.nextLine();
	        ZoneId targetZoneId = ZoneId.of(targetTimezone);

	        ZonedDateTime targetZonedDateTime = sourceZonedDateTime.withZoneSameInstant(targetZoneId);

	        String formattedTargetTime = targetZonedDateTime.format(formatter);
	        System.out.println("The time in " + targetTimezone + " is: " + formattedTargetTime);
	        
	        scanner.close();
	    }
	}
