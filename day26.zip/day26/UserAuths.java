package day26;

public class UserAuths {

}
